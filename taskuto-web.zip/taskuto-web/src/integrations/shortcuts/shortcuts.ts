/**
 * iOS Shortcuts bridge.
 * The app calls these names to mirror the Swift version:
 * 勉強開始 / 勉強再開 / 勉強中断 / 勉強中止 / 勉強終了
 */
export function runShortcut(name:string){
  if(typeof window==='undefined' || !('ontouchstart' in window)) return false
  window.location.href=`shortcuts://run-shortcut?name=${encodeURIComponent(name)}`
  return true
}
