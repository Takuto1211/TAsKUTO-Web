/**
 * Studyplus integration boundary.
 * Official Studyplus API access requires separate approval/credentials.
 * Keep this adapter isolated so the rest of TAsKUTO never depends on it.
 */
export interface StudyplusRecord {
  title:string
  durationMinutes:number
  startedAt:string
}
export async function submitStudyplusRecord(_record:StudyplusRecord):Promise<{ok:false;reason:string}>{
  return {ok:false,reason:'Studyplus API credentials are not configured.'}
}
