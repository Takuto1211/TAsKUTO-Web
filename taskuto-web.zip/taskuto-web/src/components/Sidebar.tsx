import { motion } from 'motion/react'
import { Icon } from './Icons'
import { useTaskutoStore } from '../store/useTaskutoStore'
import { Streak } from './Streak'
import type { ViewName } from '../lib/types'

const items:{view:ViewName;label:string;icon:string}[]=[{view:'daily',label:'日別',icon:'calendar'},{view:'tasks',label:'タスク一覧',icon:'list'},{view:'completed',label:'完了済み',icon:'check'},{view:'settings',label:'設定',icon:'settings'}]

export function Sidebar({mobile=false}:{mobile?:boolean}){
 const view=useTaskutoStore(s=>s.currentView),setView=useTaskutoStore(s=>s.setView),profile=useTaskutoStore(s=>s.profile),sync=useTaskutoStore(s=>s.syncMessage),signOut=useTaskutoStore(s=>s.signOut),connected=useTaskutoStore(s=>s.connected),email=useTaskutoStore(s=>s.authEmail)
 return <aside className={mobile?'sidebar mobile-sidebar':'sidebar'}>
   <div className="brand">TAs<span>K</span>UTO</div>
   <div className="profile glass-card"><div className="avatar">{profile.avatarUrl?<img src={profile.avatarUrl} alt=""/>:<Icon name="user"/>}</div><div className="profile-meta"><strong>{profile.displayName}</strong>{email&&<span>{email}</span>}</div></div>
   <div className="menu-label">MENU</div>
   <nav>{items.map(item=><motion.button key={item.view} whileTap={{scale:.98}} className={`nav-item ${view===item.view?'active':''}`} onClick={()=>setView(item.view)}><Icon name={item.icon}/><span>{item.label}</span></motion.button>)}</nav>
   <div className="sidebar-bottom"><Streak/><div className="sync-pill"><span className={`dot ${connected?'online':''}`}/>{sync}</div>{email&&<button className="logout" onClick={()=>void signOut()}><Icon name="logout"/>ログアウト</button>}</div>
 </aside>
}
