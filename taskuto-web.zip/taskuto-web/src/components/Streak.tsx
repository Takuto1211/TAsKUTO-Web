import { motion } from 'motion/react'
import { useTaskutoStore } from '../store/useTaskutoStore'
import { GlassCard } from './Glass'

export function Streak(){
  const days=useTaskutoStore(s=>s.streak())
  const theme=useTaskutoStore(s=>s.settings.theme)
  const level=days>=30?4:days>=14?3:days>=7?2:days>=3?1:0
  const title=level===4?'👑 伝説の継続！':level===3?'💎 驚異の達成率！':level===2?'🔥 絶好調！':level===1?'✨ いい調子！':'🌱 連続タスク全達成'
  return <motion.div layout><GlassCard className={`streak-card level-${level} theme-${theme}`}><div className="streak-head"><strong>{title}</strong>{level>=3&&<span>✦</span>}</div><div className="streak-num">{days}<small>日</small></div><div className="streak-note">※26時までセーフ<br/>※翌日に未完了分を含め全完了＋さらに翌日全完了で日数復活</div></GlassCard></motion.div>
}
