import { useEffect, useMemo } from 'react'
import { motion } from 'motion/react'
export function Confetti({runKey}:{runKey:number}){
  const pieces=useMemo(()=>Array.from({length:80},(_,i)=>({id:`${runKey}-${i}`,x:(Math.random()-.5)*2,y:-(.8+Math.random()*.9),drift:(Math.random()-.5)*220,rotate:180+Math.random()*180,color:['#ff5f7e','#5b9ff0','#5ed39c','#f1cf48','#ed873c','#9d75d6','#39b8e9','#e96c99'][i%8]})),[runKey])
  useEffect(()=>{ /* lifecycle intentionally tied to runKey */ },[runKey])
  return <div className="confetti-layer" aria-hidden>{pieces.map(p=><motion.span key={p.id} className="confetti-piece" initial={{x:`calc(50vw + ${p.x*50}vw)`,y:'105vh',rotate:0,opacity:1}} animate={{x:`calc(50vw + ${p.drift}px)`,y:'18vh',rotate:p.rotate,opacity:1}} transition={{duration:.9,ease:'easeOut'}}><motion.i animate={{y:'68vh',x:p.drift/2,rotate:p.rotate+Math.random()*720,opacity:0}} transition={{duration:2.2,delay:.88,ease:'easeIn'}} style={{background:p.color}}/></motion.span>)}</div>
}
