import { useState, type FormEvent } from 'react'
import { motion } from 'motion/react'
import { useTaskutoStore } from '../store/useTaskutoStore'
import { hasSupabaseConfig } from '../lib/supabase'

export function AuthGate() {
  const signIn = useTaskutoStore(s=>s.signIn)
  const signUp = useTaskutoStore(s=>s.signUp)
  const [email,setEmail]=useState('')
  const [password,setPassword]=useState('')
  const [mode,setMode]=useState<'login'|'signup'>('login')
  const [error,setError]=useState<string|null>(null)
  const [busy,setBusy]=useState(false)
  if (!hasSupabaseConfig) return null
  const submit=async(e:FormEvent)=>{
    e.preventDefault(); setBusy(true); setError(null)
    const message=mode==='login'?await signIn(email,password):await signUp(email,password)
    if(message) setError(message)
    else if(mode==='signup') setError('確認メールが必要な設定の場合は、メール内のリンクを開いてください。')
    setBusy(false)
  }
  return <div className="auth-screen">
    <motion.div className="auth-card glass-card" initial={{opacity:0,y:18,scale:.98}} animate={{opacity:1,y:0,scale:1}}>
      <div className="brand-mark">TAs<span>K</span>UTO</div>
      <p className="auth-subtitle">複数デバイスで同期するにはログインしてください。</p>
      <form onSubmit={submit} className="stack">
        <label>メールアドレス<input type="email" required value={email} onChange={e=>setEmail(e.target.value)} autoComplete="email" /></label>
        <label>パスワード<input type="password" minLength={6} required value={password} onChange={e=>setPassword(e.target.value)} autoComplete={mode==='login'?'current-password':'new-password'} /></label>
        {error && <div className="form-error">{error}</div>}
        <button className="primary-btn large" disabled={busy}>{busy?'処理中…':mode==='login'?'ログイン':'アカウント作成'}</button>
      </form>
      <button className="text-btn" onClick={()=>{setMode(mode==='login'?'signup':'login');setError(null)}}>{mode==='login'?'初めて使う → アカウント作成':'ログインへ戻る'}</button>
    </motion.div>
  </div>
}
