import { useEffect, useState } from 'react'
import { motion, AnimatePresence } from 'motion/react'
import { useTaskutoStore } from '../store/useTaskutoStore'
import { GlassCard, GlassButton } from './Glass'

function fmt(sec:number){const s=Math.max(0,Math.floor(sec));const h=Math.floor(s/3600),m=Math.floor((s%3600)/60),ss=s%60;return h>0?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(ss).padStart(2,'0')}`}

export function TimerLayer(){
  const timer=useTaskutoStore(s=>s.timer); const tasks=useTaskutoStore(s=>s.tasks); const toggle=useTaskutoStore(s=>s.toggleTimer); const finish=useTaskutoStore(s=>s.finishTimer); const cancel=useTaskutoStore(s=>s.cancelTimer); const setMode=useTaskutoStore(s=>s.setTimerMode); const setDuration=useTaskutoStore(s=>s.setTimerDuration)
  const [now,setNow]=useState(Date.now()); const [expanded,setExpanded]=useState(false); const [finishOpen,setFinishOpen]=useState(false)
  useEffect(()=>{const id=window.setInterval(()=>setNow(Date.now()),250);return()=>clearInterval(id)},[])
  if(!timer.activeTaskId)return null
  const task=tasks.find(t=>t.id===timer.activeTaskId); const elapsed=timer.isRunning&&timer.startedAt?Math.floor(timer.accumulatedSeconds+(now-new Date(timer.startedAt).getTime())/1000):Math.floor(timer.accumulatedSeconds); const remaining=Math.max(0,Math.ceil(timer.totalDurationSeconds-elapsed)); const overtime=Math.max(0,elapsed-timer.totalDurationSeconds)
  const isTimer=timer.mode==='timer'
  const durationMinutes=Math.max(0,Math.round(timer.totalDurationSeconds/60))
  const h=Math.floor(durationMinutes/60), m=durationMinutes%60
  return <>
    <AnimatePresence>
      {!expanded&&<motion.div className="compact-timer-wrap" initial={{y:100,opacity:0}} animate={{y:0,opacity:1}} exit={{y:100,opacity:0}}><GlassCard className="compact-timer"><div><div className={`timer-small ${overtime>0?'overtime':''}`}>{isTimer?(remaining>0?fmt(remaining):`+${fmt(overtime)}`):fmt(elapsed)}</div><div className="timer-task">{task?.name??'タスク'}</div></div><div className="timer-controls"><button className="circle-action" onClick={()=>void toggle()}>{timer.isRunning?'Ⅱ':'▶'}</button><button className="circle-action success" onClick={()=>setFinishOpen(true)} disabled={!timer.hasStarted}>✓</button><button className="mini-expand" onClick={()=>setExpanded(true)}>↗</button></div></GlassCard></motion.div>}
    </AnimatePresence>
    {expanded&&<div className="timer-fullscreen"><div className="timer-top"><span className="grabber"/><button className="icon-btn timer-close" onClick={()=>setExpanded(false)}>↙</button></div><div className="timer-content"><h1>{task?.name??'タスク'}</h1><div className="segmented"><button className={isTimer?'selected':''} onClick={()=>void setMode('timer')}>タイマー</button><button className={!isTimer?'selected':''} onClick={()=>void setMode('stopwatch')}>ストップウォッチ</button></div>{isTimer&&!timer.hasStarted&&<div className="duration-picker"><select value={h} onChange={e=>void setDuration(Number(e.target.value),m)}>{Array.from({length:13},(_,i)=><option key={i} value={i}>{i}h</option>)}</select><select value={m} onChange={e=>void setDuration(h,Number(e.target.value))}>{Array.from({length:60},(_,i)=><option key={i} value={i}>{String(i).padStart(2,'0')}m</option>)}</select></div>}<div className={`timer-big ${overtime>0?'red':''}`}>{isTimer?(remaining>0?fmt(remaining):`+${fmt(overtime)}`):fmt(elapsed)}</div><div className="timer-bottom-actions"><button className="cancel-circle" onClick={()=>void cancel()}>×</button><button className="play-big" onClick={()=>void toggle()}>{timer.isRunning?'Ⅱ':'▶'}</button><GlassButton primary disabled={!timer.hasStarted} onClick={()=>setFinishOpen(true)}>✓ 完了</GlassButton></div></div></div>}
    {finishOpen&&<div className="choice-backdrop" onPointerDown={e=>{if(e.target===e.currentTarget)setFinishOpen(false)}}><motion.div className="choice-card glass-card" initial={{opacity:0,scale:.94}} animate={{opacity:1,scale:1}}><h3>終了</h3><button onClick={()=>{setFinishOpen(false);void finish(true)}}>完了</button><button onClick={()=>{setFinishOpen(false);void finish(false)}}>中断</button><button className="cancel-choice" onClick={()=>setFinishOpen(false)}>キャンセル</button></motion.div></div>}
  </>
}
