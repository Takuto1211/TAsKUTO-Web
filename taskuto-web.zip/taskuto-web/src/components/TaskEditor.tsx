import { useEffect, useMemo, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { useTaskutoStore } from '../store/useTaskutoStore'
import type { Frequency, RecurrenceSettings, Task } from '../lib/types'
import { addDays, fromDateInputValue, toDateInputValue } from '../lib/dates'
import { GlassButton, Sheet } from './Glass'

const emptyRecurrence: RecurrenceSettings={frequency:'none',weekDays:[],weekNumbers:[],hasEndDate:false,endDate:null}

export function TaskEditor(){
  const open=useTaskutoStore(s=>s.taskEditorOpen); const editingId=useTaskutoStore(s=>s.editingTaskId); const initialDate=useTaskutoStore(s=>s.initialTaskDate)
  const task=useTaskutoStore(s=>s.tasks.find(t=>t.id===editingId)); const sections=useTaskutoStore(s=>s.sections); const settings=useTaskutoStore(s=>s.settings)
  const createTask=useTaskutoStore(s=>s.createTask); const updateTask=useTaskutoStore(s=>s.updateTask); const deleteTask=useTaskutoStore(s=>s.deleteTask); const close=useTaskutoStore(s=>s.closeEditor); const addSection=useTaskutoStore(s=>s.addSection); const notify=useTaskutoStore(s=>s.notify)
  const [name,setName]=useState(''); const [memo,setMemo]=useState(''); const [sectionId,setSectionId]=useState(settings.defaultSectionId); const [isStudy,setIsStudy]=useState(settings.defaultIsStudy)
  const [start,setStart]=useState(toDateInputValue(initialDate?new Date(initialDate):new Date())); const [end,setEnd]=useState(start); const [recurrence,setRecurrence]=useState<RecurrenceSettings>(emptyRecurrence)
  const [newSection,setNewSection]=useState(''); const [saveChoice,setSaveChoice]=useState(false); const [deleteChoice,setDeleteChoice]=useState(false)
  const isEdit=Boolean(task)
  useEffect(()=>{
    if(!open)return
    if(task){ setName(task.name);setMemo(task.memo);setSectionId(task.sectionId);setIsStudy(task.isStudy);setStart(toDateInputValue(task.startAt));setEnd(toDateInputValue(task.endAt));setRecurrence(task.recurrence) }
    else { const s=initialDate?toDateInputValue(initialDate):toDateInputValue(new Date());setName('');setMemo('');setSectionId(settings.defaultSectionId);setIsStudy(settings.defaultIsStudy);setStart(s);setEnd(s);setRecurrence(emptyRecurrence) }
  },[open,task?.id,initialDate,settings.defaultSectionId,settings.defaultIsStudy])

  const frequencyLabel:Record<Frequency,string>={none:'なし',daily:'毎日',weekly:'毎週',monthly:'毎月'}
  const validSection=useMemo(()=>sections.some(s=>s.id===sectionId&&s.name!=='全て')?sectionId:'00000000-0000-0000-0000-000000000003',[sections,sectionId])
  const save=async(applyAll=false)=>{
    if(!name.trim())return
    const recurrenceToSave={...recurrence,weekDays:[...recurrence.weekDays],weekNumbers:[...recurrence.weekNumbers]}
    if(isEdit&&task) await updateTask(task.id,{name:name.trim(),memo,sectionId:validSection,isStudy,startAt:fromDateInputValue(start),endAt:fromDateInputValue(end),recurrence:recurrenceToSave},applyAll)
    else await createTask({name:name.trim(),memo,sectionId:validSection,isStudy,startAt:fromDateInputValue(start),endAt:fromDateInputValue(end),recurrence:recurrenceToSave})
    close()
  }
  const addNewSection=async()=>{ if(!newSection.trim())return; await addSection(newSection); const created=useTaskutoStore.getState().sections.find(s=>s.name===newSection.trim()); if(created)setSectionId(created.id);setNewSection('') }
  const confirmDelete=async(mode:'one'|'following'|'all')=>{ if(task){await deleteTask(task.id,mode);close()} }
  const toggleDay=(n:number)=>setRecurrence(r=>({...r,weekDays:r.weekDays.includes(n)?r.weekDays.filter(x=>x!==n):[...r.weekDays,n].sort((a,b)=>a-b)}))
  const toggleWeek=(n:number)=>setRecurrence(r=>({...r,weekNumbers:r.weekNumbers.includes(n)?r.weekNumbers.filter(x=>x!==n):[...r.weekNumbers,n].sort((a,b)=>a-b)}))

  return <Sheet open={open} onClose={close} title={isEdit?'編集':'追加'}>
    <div className="editor-scroll">
      <div className="form-grid">
        <label>タスク名<input autoFocus value={name} onChange={e=>setName(e.target.value)} placeholder="タスク名" /></label>
        <label>メモ<textarea value={memo} onChange={e=>setMemo(e.target.value)} rows={3} placeholder="メモ（任意）" /></label>
      </div>
      <div className="form-section">
        <div className="setting-row"><span>勉強タスク</span><button className={`switch ${isStudy?'on':''}`} onClick={()=>setIsStudy(v=>!v)} aria-pressed={isStudy}><span/></button></div>
        <div className="form-label">セクション</div>
        <div className="section-select-row"><select value={validSection} onChange={e=>setSectionId(e.target.value)}>{sections.filter(s=>s.name!=='全て').map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select><button className="small-round" onClick={addNewSection}>＋</button></div>
        <div className="inline-new-section"><input value={newSection} onChange={e=>setNewSection(e.target.value)} placeholder="新しいセクション" /><button onClick={addNewSection}>追加</button></div>
      </div>
      <div className="form-section">
        <div className="date-grid"><label>開始日<input type="date" value={start} onChange={e=>{setStart(e.target.value);if(e.target.value>end)setEnd(e.target.value)}} /></label><label>終了日<input type="date" min={start} value={end} onChange={e=>setEnd(e.target.value)} /></label></div>
      </div>
      <div className="form-section">
        <div className="form-label">繰り返し</div>
        <select value={recurrence.frequency} onChange={e=>{const frequency=e.target.value as Frequency;setRecurrence(r=>({...r,frequency,weekDays:frequency==='weekly'&&r.weekDays.length===0?[new Date(fromDateInputValue(start)).getDay()+1]:r.weekDays}))}}>{(Object.keys(frequencyLabel) as Frequency[]).map(f=><option key={f} value={f}>{frequencyLabel[f]}</option>)}</select>
        <AnimatePresence initial={false}>
          {recurrence.frequency!=='none'&&<motion.div initial={{opacity:0,height:0}} animate={{opacity:1,height:'auto'}} exit={{opacity:0,height:0}} className="recurrence-panel">
            <div className="setting-row"><span>繰り返しの終了日</span><button className={`switch ${recurrence.hasEndDate?'on':''}`} onClick={()=>setRecurrence(r=>({...r,hasEndDate:!r.hasEndDate,endDate:r.hasEndDate?null:r.endDate??end}))} aria-pressed={recurrence.hasEndDate}><span/></button></div>
            {recurrence.hasEndDate&&<input type="date" min={end} value={recurrence.endDate??end} onChange={e=>setRecurrence(r=>({...r,endDate:e.target.value}))} />}
            {recurrence.frequency==='weekly'&&<>
              <div className="form-label small">曜日</div><div className="week-grid">{[1,2,3,4,5,6,7].map((n,i)=><button key={n} className={recurrence.weekDays.includes(n)?'selected':''} onClick={()=>toggleDay(n)}>{['日','月','火','水','木','金','土'][i]}</button>)}</div>
              <div className="form-label small">週</div><div className="week-grid five">{[1,2,3,4,5].map(n=><button key={n} className={recurrence.weekNumbers.includes(n)?'selected':''} onClick={()=>toggleWeek(n)}>第{n}</button>)}</div>
            </>}
          </motion.div>}
        </AnimatePresence>
      </div>
      {isEdit&&<button className="danger-outline full" onClick={()=>setDeleteChoice(true)}>このタスクを削除</button>}
    </div>
    <div className="sheet-actions"><GlassButton onClick={close}>キャンセル</GlassButton><GlassButton primary disabled={!name.trim()} onClick={()=>{if(isEdit&&task?.recurrence.frequency!=='none')setSaveChoice(true);else void save(false)}}>保存</GlassButton></div>
    {saveChoice&&<ModalChoice title="繰り返しタスクの保存" options={[['この日のみ変更する',()=>{setSaveChoice(false);void save(false)}],['以降全てのタスクを変更する',()=>{setSaveChoice(false);void save(true)}]]} onClose={()=>setSaveChoice(false)}/>} 
    {deleteChoice&&<ModalChoice title="削除" options={task?.recurrence.frequency!=='none'?[['この日のみを削除する',()=>{setDeleteChoice(false);void confirmDelete('one')}],['これ以降全てのタスクを削除する',()=>{setDeleteChoice(false);void confirmDelete('following')}]]:[['完全に削除する',()=>{setDeleteChoice(false);void confirmDelete('one')}]]} onClose={()=>setDeleteChoice(false)}/>} 
  </Sheet>
}

function ModalChoice({title,options,onClose}:{title:string;options:[string,()=>void][];onClose:()=>void}){return <div className="choice-backdrop" onPointerDown={e=>{if(e.target===e.currentTarget)onClose()}}><motion.div className="choice-card glass-card" initial={{opacity:0,scale:.94}} animate={{opacity:1,scale:1}}><h3>{title}</h3>{options.map(([label,fn])=><button key={label} onClick={fn}>{label}</button>)}<button className="cancel-choice" onClick={onClose}>キャンセル</button></motion.div></div>}
