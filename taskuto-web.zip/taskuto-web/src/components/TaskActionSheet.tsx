import { motion } from 'motion/react'
import { useTaskutoStore } from '../store/useTaskutoStore'
import { formatDateTime } from '../lib/dates'

export function TaskActionSheet(){
 const id=useTaskutoStore(s=>s.actionTaskId),task=useTaskutoStore(s=>s.tasks.find(t=>t.id===id)),set=useTaskutoStore(s=>s.setActionTask),openEdit=useTaskutoStore(s=>s.openEdit),prepare=useTaskutoStore(s=>s.prepareTimer),complete=useTaskutoStore(s=>s.completeTask),restore=useTaskutoStore(s=>s.restoreTask)
 if(!id||!task)return null
 const close=()=>set(null)
 return <div className="action-backdrop" onPointerDown={e=>{if(e.target===e.currentTarget)close()}}><motion.div className="action-sheet glass-card" initial={{y:30,opacity:0}} animate={{y:0,opacity:1}}><div className="sheet-handle"/><div className="action-title"><strong>{task.name}</strong>{task.memo&&<span>{task.memo}</span>}{task.isCompleted&&task.completedAt&&<small>完了: {formatDateTime(task.completedAt)}</small>}</div>{task.isCompleted?<button onClick={()=>{close();void restore(task.id)}}>↶ タスク復元</button>:<><button onClick={()=>{close();void prepare(task)}}>▶ タスク開始</button><button onClick={()=>{close();void complete(task.id)}}>✓ タスク完了</button></>}<button onClick={()=>{close();openEdit(task)}}>✎ 編集</button><button className="cancel-choice" onClick={close}>キャンセル</button></motion.div></div>
}
