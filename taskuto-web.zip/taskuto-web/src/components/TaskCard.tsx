import { useRef, useState } from 'react'
import { motion } from 'motion/react'
import type { Task } from '../lib/types'
import { formatDay, isMultiDay, isOverdue, sameDay } from '../lib/dates'
import { useTaskutoStore } from '../store/useTaskutoStore'

export function TaskCard({task,compact=false,reorderMode=false,selected=false,onLongPress,onDragEnd}:{task:Task;compact?:boolean;reorderMode?:boolean;selected?:boolean;onLongPress:()=>void;onDragEnd?:(x:number,y:number)=>void}){
 const [pressed,setPressed]=useState(false); const timer=useRef<number|null>(null); const moved=useRef(false); const startPoint=useRef({x:0,y:0})
 const clear=()=>{if(timer.current!==null){window.clearTimeout(timer.current);timer.current=null}setPressed(false)}
 const start=(e:import('react').PointerEvent)=>{if(reorderMode)return;moved.current=false;startPoint.current={x:e.clientX,y:e.clientY};setPressed(true);timer.current=window.setTimeout(()=>{moved.current=true;setPressed(false);onLongPress()},420);}
 const move=(e:import('react').PointerEvent)=>{if(Math.hypot(e.clientX-startPoint.current.x,e.clientY-startPoint.current.y)>8){moved.current=true;if(timer.current!==null){window.clearTimeout(timer.current);timer.current=null}}}
 const end=()=>{if(timer.current!==null){window.clearTimeout(timer.current);timer.current=null}setPressed(false)}
 const action=useTaskutoStore(s=>s.setActionTask)
 return <motion.div
   className={`task-card ${compact?'compact':''} ${selected?'selected':''} ${pressed?'long-pressed':''} ${reorderMode?'reorderable':''}`}
   whileTap={{scale:reorderMode?.98:.985}}
   drag={reorderMode}
   dragMomentum={true}
   dragElastic={0.12}
   whileDrag={{scale:1.035,boxShadow:'0 18px 40px rgba(0,0,0,.20)',zIndex:30}}
   onDragEnd={(_e,info)=>{if(onDragEnd&&(Math.abs(info.offset.x)>2||Math.abs(info.offset.y)>2))onDragEnd(info.point.x,info.point.y)}}
   onPointerDown={start} onPointerMove={move} onPointerUp={end} onPointerCancel={clear}
   onClick={()=>{if(!reorderMode&&!moved.current)action(task.id)}}
 >
   <div className="task-main"><div className="task-title-row">{task.recurrence.frequency!=='none'&&<span className="repeat-icon">↻</span>}<span className={task.isCompleted?'completed-text':''}>{task.name}</span></div><div className="task-sub-row">{isMultiDay(task)?<span className={isOverdue(task)?'overdue':''}>期間: {formatDay(task.startAt)}〜{formatDay(task.endAt)}</span>:<span className={isOverdue(task)?'overdue':''}>期限: {formatDay(task.endAt)}</span>}{task.memo&&<span className="memo-preview">{task.memo}</span>}</div></div>
   <div className={`task-state ${task.isCompleted?'done':''}`}>{task.isCompleted?'✓':'○'}</div>
   {reorderMode&&<span className="drag-dots">⋮⋮</span>}
 </motion.div>
}

export function CalendarTask({task,reorderMode,selected,onLongPress,onDragEnd}:{task:Task;reorderMode:boolean;selected:boolean;onLongPress:()=>void;onDragEnd?:(x:number,y:number)=>void}){
 return <TaskCard task={task} compact reorderMode={reorderMode} selected={selected} onLongPress={onLongPress} onDragEnd={onDragEnd}/>
}
