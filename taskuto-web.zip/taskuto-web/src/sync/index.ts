/**
 * Sync responsibilities currently live in useTaskutoStore.ts.
 * This module intentionally documents the boundary so the sync engine can be
 * extracted later without changing feature components.
 */
export const syncArchitecture = {
  sourceOfTruth: 'supabase',
  localCache: 'indexeddb',
  realtime: 'supabase-realtime',
  conflict: 'last-write-wins-by-updated-at'
} as const
