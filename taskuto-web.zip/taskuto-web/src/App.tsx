import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'motion/react'
import { useTaskutoStore } from './store/useTaskutoStore'
import { hasSupabaseConfig, supabase } from './lib/supabase'
import { THEMES } from './lib/themes'
import { Sidebar } from './components/Sidebar'
import { AuthGate } from './components/AuthGate'
import { TaskEditor } from './components/TaskEditor'
import { TimerLayer } from './components/Timer'
import { TaskActionSheet } from './components/TaskActionSheet'
import { Confetti } from './components/Confetti'
import { CalendarView } from './features/calendar/CalendarView'
import { TaskListView } from './features/tasks/TaskListView'
import { CompletedView } from './features/completed/CompletedView'
import { SettingsView } from './features/settings/SettingsView'
import { GlassButton } from './components/Glass'

export default function App(){
 const ready=useTaskutoStore(s=>s.ready),userId=useTaskutoStore(s=>s.userId),view=useTaskutoStore(s=>s.currentView),drawer=useTaskutoStore(s=>s.drawerOpen),setDrawer=useTaskutoStore(s=>s.setDrawer),openAdd=useTaskutoStore(s=>s.openAdd),settings=useTaskutoStore(s=>s.settings),confettiKey=useTaskutoStore(s=>s.confettiKey),toast=useTaskutoStore(s=>s.toast),init=useTaskutoStore(s=>s.init)
 const [dark,setDark]=useState(()=>window.matchMedia?.('(prefers-color-scheme: dark)').matches??false)
 useEffect(()=>{void init(); if(!supabase)return; const {data}=supabase.auth.onAuthStateChange(()=>void useTaskutoStore.getState().init()); return()=>data.subscription.unsubscribe()},[init])
 useEffect(()=>{const tokens=THEMES[settings.theme];document.documentElement.style.setProperty('--accent',tokens.accent);document.documentElement.style.setProperty('--accent2',tokens.accent2);document.documentElement.style.setProperty('--light-bg',tokens.lightBg);document.documentElement.style.setProperty('--dark-bg',tokens.darkBg);document.documentElement.style.setProperty('--glow',tokens.glow);document.documentElement.dataset.theme=settings.theme;document.documentElement.dataset.mode=dark?'dark':'light'},[settings.theme,dark])
 if(!ready)return <div className="loading-screen"><div className="brand-mark">TAs<span>K</span>UTO</div><div className="loading-orb"/></div>
 if(hasSupabaseConfig && userId==='anonymous')return <AuthGate/>
 const page=view==='daily'?<CalendarView/>:view==='tasks'?<TaskListView/>:view==='completed'?<CompletedView/>:<SettingsView/>
 return <div className="app-root"><Sidebar/>{drawer&&<div className="mobile-drawer-wrap"><div className="drawer-shade" onPointerDown={()=>setDrawer(false)}/><motion.div className="mobile-drawer" initial={{x:-330}} animate={{x:0}} exit={{x:-330}}><Sidebar mobile/></motion.div></div>}<main className="main"><div className="mobile-top"><button className="icon-btn" onClick={()=>setDrawer(true)}>☰</button><div className="mobile-brand">TAs<span>K</span>UTO</div><button className="icon-btn" onClick={()=>openAdd()}>＋</button></div>{page}</main>{(view==='daily'||view==='tasks')&&<motion.button className="fab" whileTap={{scale:.92}} whileHover={{scale:1.05}} onClick={()=>openAdd()}>＋</motion.button>}<TaskEditor/><TaskActionSheet/><TimerLayer/>{confettiKey>0&&<Confetti runKey={confettiKey}/>}<AnimatePresence>{toast&&<motion.div className="toast" initial={{opacity:0,y:16}} animate={{opacity:1,y:0}} exit={{opacity:0,y:10}}>{toast}</motion.div>}</AnimatePresence><div className="dev-badge">{hasSupabaseConfig?'☁ ONLINE / SYNC':'◌ LOCAL DEMO'} </div><button className="mode-toggle" onClick={()=>setDark(v=>!v)} aria-label="ライト/ダーク切替">{dark?'☀':'☾'}</button></div>
}
