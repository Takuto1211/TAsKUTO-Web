import { useTaskutoStore } from '../../store/useTaskutoStore'
import { GlassCard } from '../../components/Glass'
import { formatDateTime } from '../../lib/dates'
export function CompletedView(){
 const tasks=useTaskutoStore(s=>s.tasks).filter(t=>t.isCompleted).sort((a,b)=>new Date(b.completedAt??0).getTime()-new Date(a.completedAt??0).getTime()); const restore=useTaskutoStore(s=>s.restoreTask); const del=useTaskutoStore(s=>s.deleteCompletedTask); const delAll=useTaskutoStore(s=>s.deleteAllCompleted); const period=useTaskutoStore(s=>s.settings.autoDeletePeriod)
 return <div className="page list-page"><div className="page-head"><div><h1>完了済みタスク</h1><p>完了日時の新しい順です。</p></div><button className="danger-btn" onClick={()=>void delAll()} disabled={!tasks.length}>全て削除</button></div>{!tasks.length?<div className="empty-state glass-card"><div className="empty-icon">✓</div><h2>完了済みのタスクはありません</h2></div>:<div className="completed-list">{tasks.map(t=><GlassCard key={t.id} className="completed-card"><div><h3>{t.name}</h3><p>完了日時: {t.completedAt?formatDateTime(t.completedAt):'—'}</p></div><div className="completed-actions"><button className="icon-btn" onClick={()=>void restore(t.id)} title="復元">↶</button><button className="icon-btn danger-icon" onClick={()=>void del(t.id)} title="削除">⌫</button></div></GlassCard>)}</div>}<p className="auto-delete-note">※完了から{period}日後に自動削除されます</p></div>
}
