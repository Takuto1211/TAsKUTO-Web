import { useEffect, useState } from 'react'
import { AnimatePresence } from 'motion/react'
import { useTaskutoStore } from '../../store/useTaskutoStore'
import { TaskCard } from '../../components/TaskCard'
import { GlassButton } from '../../components/Glass'
import type { SortOption } from '../../lib/types'

export function TaskListView(){
 const tasks=useTaskutoStore(s=>s.tasks),sections=useTaskutoStore(s=>s.sections),openEdit=useTaskutoStore(s=>s.openEdit),settings=useTaskutoStore(s=>s.settings),updateSettings=useTaskutoStore(s=>s.updateSettings)
 const [sort,setSort]=useState<SortOption>(settings.sortOption)
 useEffect(()=>setSort(settings.sortOption),[settings.sortOption])
 const active=tasks.filter(t=>!t.isHidden&&!t.isCompleted&&!t.isDailyCleared)
 const sorted=(list:typeof tasks)=>[...list].sort((a,b)=>{if(a.recurrence.frequency!=='none'&&b.recurrence.frequency==='none')return -1;if(a.recurrence.frequency==='none'&&b.recurrence.frequency!=='none')return 1;if(sort==='nameAsc')return a.name.localeCompare(b.name,'ja');if(sort==='nameDesc')return b.name.localeCompare(a.name,'ja');if(sort==='createdAtAsc')return a.createdAt.localeCompare(b.createdAt);if(sort==='createdAtDesc')return b.createdAt.localeCompare(a.createdAt);return a.customOrder-b.customOrder})
 return <div className="page list-page"><div className="page-head"><div><h1>タスク一覧</h1><p>未完了のタスクをセクションごとに表示します。</p></div><select className="head-select" value={sort} onChange={e=>{const v=e.target.value as SortOption;setSort(v);void updateSettings({sortOption:v})}}><option value="custom">カスタム</option><option value="nameAsc">名前（昇順）</option><option value="nameDesc">名前（降順）</option><option value="createdAtAsc">作成日（古い順）</option><option value="createdAtDesc">作成日（新しい順）</option></select></div>{active.length===0?<div className="empty-state glass-card"><div className="empty-icon">✓</div><h2>タスクがありません</h2><p>右下の＋から新しいタスクを追加できます。</p></div>:<div className="section-list">{sections.filter(s=>s.name!=='全て').map(sec=>{const list=sorted(active.filter(t=>t.sectionId===sec.id));return list.length?<section key={sec.id}><h2>{sec.name}</h2><AnimatePresence>{list.map(task=><TaskCard key={task.id} task={task} onLongPress={()=>openEdit(task)}/>)}</AnimatePresence></section>:null})}</div>}<div className="list-tip"><GlassButton>タップで開始/完了</GlassButton><span>長押しで編集</span></div></div>
}
