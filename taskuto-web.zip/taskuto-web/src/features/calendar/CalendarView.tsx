import { useMemo, useRef, useState, type CSSProperties, type PointerEvent as ReactPointerEvent } from 'react'
import { motion } from 'motion/react'
import { useTaskutoStore } from '../../store/useTaskutoStore'
import type { Task } from '../../lib/types'
import { addDays, formatDay, isMultiDay, sameDay } from '../../lib/dates'
import { GlassButton } from '../../components/Glass'
import { CalendarTask, TaskCard } from '../../components/TaskCard'

const RANGE_START = -30
const RANGE_END = 60

export function CalendarView(){
  const tasks = useTaskutoStore(s=>s.tasks)
  const sections = useTaskutoStore(s=>s.sections)
  const openAdd = useTaskutoStore(s=>s.openAdd)
  const openEdit = useTaskutoStore(s=>s.openEdit)
  const batchMove = useTaskutoStore(s=>s.batchMove)
  const reorderTask = useTaskutoStore(s=>s.reorderTask)
  const [reorderMode,setReorderMode] = useState(false)
  const [multi,setMulti] = useState(false)
  const [selected,setSelected] = useState<string[]>([])
  const [columnWidth,setColumnWidth] = useState(78)
  const [batchDate,setBatchDate] = useState('')
  const [showBatch,setShowBatch] = useState(false)
  const scroller = useRef<HTMLDivElement>(null)
  const today = new Date()
  const dates = useMemo(()=>Array.from({length:RANGE_END-RANGE_START+1},(_,i)=>addDays(today,RANGE_START+i)),[])
  const activeSections = sections.filter(s=>s.name!=='全て')

  const singleFor = (date:Date) => tasks.filter(t=>!t.isHidden&&!isMultiDay(t)&&sameDay(t.startAt,date)).sort((a,b)=>a.customOrder-b.customOrder)
  const multiTasks = tasks.filter(t=>!t.isHidden&&!t.isDailyCleared&&isMultiDay(t))
  const goToday=()=>requestAnimationFrame(()=>scroller.current?.scrollTo({left:(-RANGE_START)*columnWidth-40,behavior:'smooth'}))
  const goOldest=()=>{
    const candidates=tasks.filter(t=>!t.isCompleted&&!t.isHidden&&!t.isDailyCleared).map(t=>new Date(t.startAt).getTime())
    if(!candidates.length){goToday();return}
    const oldest=new Date(Math.min(...candidates))
    const diff=Math.round((startOf(oldest).getTime()-startOf(today).getTime())/86400000)
    const clamped=Math.max(RANGE_START,Math.min(RANGE_END,diff))
    requestAnimationFrame(()=>scroller.current?.scrollTo({left:(clamped-RANGE_START)*columnWidth-40,behavior:'smooth'}))
  }
  const onDrag=(task:Task,x:number,_y:number)=>{
    const rect=scroller.current?.getBoundingClientRect(); if(!rect)return
    const localX=x-rect.left+(scroller.current?.scrollLeft??0)
    const idx=Math.max(0,Math.min(dates.length-1,Math.floor(localX/columnWidth)))
    void reorderTask(task.id,null,dates[idx])
  }
  const toggleSelect=(id:string)=>setSelected(v=>v.includes(id)?v.filter(x=>x!==id):[...v,id])

  return <div className="page calendar-page">
    <div className="page-head">
      <div><h1>日別</h1><p>💡 空白をダブルタップ/クリックで追加 / タップで実行・長押しで編集</p></div>
      <div className="head-actions">
        <div className="action-row">{reorderMode&&<GlassButton active={multi} onClick={()=>{setMulti(v=>!v);setSelected([])}}>□ 複数選択</GlassButton>}<GlassButton active={reorderMode} onClick={()=>{setReorderMode(v=>!v);setMulti(false);setSelected([])}}>{reorderMode?'完了':'並び替え'}</GlassButton></div>
        <div className="action-row"><GlassButton onClick={goOldest}>↤ 最古</GlassButton><GlassButton onClick={goToday}>今日へ</GlassButton></div>
      </div>
    </div>
    <div className="width-control"><span>幅調整:</span><input aria-label="日付列の幅" type="range" min="55" max="140" value={columnWidth} onChange={e=>setColumnWidth(Number(e.target.value))}/><span>{columnWidth}px</span></div>
    <div className="calendar-shell glass-card" ref={scroller}>
      <div className="calendar-grid" style={{'--col':`${columnWidth}px`} as CSSProperties}>
        <div className="calendar-header-row">{dates.map((d,i)=><div key={i} className={`day-header ${sameDay(d,today)?'today':''}`}><span>{new Intl.DateTimeFormat('ja-JP',{weekday:'short'}).format(d)}</span><b>{d.getDate()}</b></div>)}</div>
<div className="single-row">{dates.map((d,i)=><DayColumn key={i} date={d} today={today} reorderMode={reorderMode} activeSections={activeSections} singleFor={singleFor} multi={multi} selected={selected} toggleSelect={toggleSelect} openEdit={openEdit} onDrag={onDrag} openAdd={openAdd} />)}</div>
        <div className="calendar-divider"/>
        <div className="multi-scroll">
          <div className="multi-row" style={{height:Math.max(240,(multiTasks.length+1)*48)}}>
            {dates.map((d,i)=><div key={i} className={`multi-column ${sameDay(d,today)?'today-col':''}`}/>)}
            {multiTasks.map((task,index)=>{
              const startIdx=Math.round((startOf(new Date(task.startAt)).getTime()-startOf(dates[0]).getTime())/86400000)
              const duration=Math.round((startOf(new Date(task.endAt)).getTime()-startOf(new Date(task.startAt)).getTime())/86400000)+1
              return <div key={task.id} className="multi-bar" style={{left:startIdx*columnWidth+3,width:Math.max(columnWidth*duration-6,columnWidth-6),top:8+index*48}}><TaskCard task={task} compact={false} reorderMode={reorderMode} selected={false} onLongPress={()=>openEdit(task)} onDragEnd={(x,y)=>onDrag(task,x,y)}/></div>
            })}
          </div>
        </div>
      </div>
    </div>
    {reorderMode&&multi&&selected.length>0&&<div className="batch-float"><span>{selected.length}件を選択中</span><button onClick={()=>{setBatchDate(toDateInput(today));setShowBatch(true)}}>別日に移動</button></div>}
    {showBatch&&<div className="modal-backdrop" onPointerDown={e=>{if(e.target===e.currentTarget)setShowBatch(false)}}><motion.div className="choice-card glass-card" initial={{opacity:0,scale:.96}} animate={{opacity:1,scale:1}}><h3>一括移動</h3><input type="date" value={batchDate} onChange={e=>setBatchDate(e.target.value)}/><button onClick={()=>{void batchMove(selected,new Date(`${batchDate}T12:00:00`));setShowBatch(false);setSelected([])}}>移動</button><button className="cancel-choice" onClick={()=>setShowBatch(false)}>キャンセル</button></motion.div></div>}
  </div>
}

function DayColumn({date,today,reorderMode,activeSections,singleFor,multi,selected,toggleSelect,openEdit,onDrag,openAdd}:{date:Date;today:Date;reorderMode:boolean;activeSections:{id:string;name:string}[];singleFor:(d:Date)=>Task[];multi:boolean;selected:string[];toggleSelect:(id:string)=>void;openEdit:(t:Task)=>void;onDrag:(t:Task,x:number,y:number)=>void;openAdd:(d:Date)=>void}){
  const longPress=useRef<number|null>(null); const [pressed,setPressed]=useState(false)
  const clear=()=>{if(longPress.current!==null){clearTimeout(longPress.current);longPress.current=null}setPressed(false)}
  const down=(e:ReactPointerEvent<HTMLDivElement>)=>{if(reorderMode||e.target!==e.currentTarget)return;setPressed(true);longPress.current=window.setTimeout(()=>{setPressed(false);openAdd(date)},420)}
  const move=(e:ReactPointerEvent<HTMLDivElement>)=>{if(Math.abs(e.movementX)+Math.abs(e.movementY)>6)clear()}
  const list=singleFor(date)
  return <div className={`day-column ${sameDay(date,today)?'today-col':''} ${pressed?'blank-pressed':''}`} onPointerDown={down} onPointerMove={move} onPointerUp={clear} onPointerCancel={clear}>
    {activeSections.map(sec=>{const sectionTasks=list.filter(t=>t.sectionId===sec.id); if(!sectionTasks.length)return null; return <div className="day-section" key={sec.id}><div className="section-label">{sec.name}</div>{sectionTasks.map(task=>multi&&reorderMode?<button key={task.id} className={`select-task ${selected.includes(task.id)?'selected':''}`} onClick={()=>toggleSelect(task.id)}><CalendarTask task={task} reorderMode={false} selected={selected.includes(task.id)} onLongPress={()=>openEdit(task)}/>{selected.includes(task.id)&&<i>✓</i>}</button>:<CalendarTask key={task.id} task={task} reorderMode={reorderMode} selected={false} onLongPress={()=>openEdit(task)} onDragEnd={(x,y)=>onDrag(task,x,y)}/>)}</div>})}
    {!list.length&&<div className="empty-day">予定なし</div>}
  </div>
}

function startOf(d:Date){const x=new Date(d);x.setHours(0,0,0,0);return x}
function toDateInput(d:Date){const x=new Date(d);return `${x.getFullYear()}-${String(x.getMonth()+1).padStart(2,'0')}-${String(x.getDate()).padStart(2,'0')}`}
