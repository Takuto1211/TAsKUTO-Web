import { create } from 'zustand'
import type { Frequency, Profile, Section, Settings, Task, ThemeName, TimerState, ViewName } from '../lib/types'
import { addDays, calculateNextDate, calculateStreak, getDurationDays, sameDay, startOfDay, cloneNextRecurringTask } from '../lib/dates'
import { idbGet, idbSet } from '../lib/idb'
import { hasSupabaseConfig, supabase } from '../lib/supabase'

const nowIso = () => new Date().toISOString()
const deviceId = (() => {
  const key = 'taskuto-device-id'
  const existing = localStorage.getItem(key)
  if (existing) return existing
  const id = crypto.randomUUID()
  localStorage.setItem(key, id)
  return id
})()

const defaultSections: Section[] = [
  { id: '00000000-0000-0000-0000-000000000000', name: '全て', sortOrder: 0, createdAt: nowIso(), updatedAt: nowIso() },
  { id: '00000000-0000-0000-0000-000000000001', name: '勉強', sortOrder: 1, createdAt: nowIso(), updatedAt: nowIso() },
  { id: '00000000-0000-0000-0000-000000000002', name: '日常', sortOrder: 2, createdAt: nowIso(), updatedAt: nowIso() },
  { id: '00000000-0000-0000-0000-000000000003', name: '未分類', sortOrder: 3, createdAt: nowIso(), updatedAt: nowIso() }
]

function defaultTask(name: string, sectionId: string, startAt: Date, memo = '', isStudy = false, recurrence: Frequency = 'none'): Task {
  const now = nowIso()
  return {
    id: crypto.randomUUID(), seriesId: recurrence === 'none' ? null : crypto.randomUUID(), name, memo, sectionId,
    startAt: startAt.toISOString(), endAt: startAt.toISOString(), isStudy, isCompleted: false, isHidden: false,
    completedAt: null, inProgress: false,
    recurrence: { frequency: recurrence, weekDays: [], weekNumbers: [], hasEndDate: false, endDate: null },
    createdAt: now, updatedAt: now, customOrder: 100, isDailyCleared: false, version: 1
  }
}

const defaultProfile: Profile = {
  id: 'local', displayName: '赤木 拓斗', avatarUrl: null, timezone: 'Asia/Tokyo', createdAt: nowIso(), updatedAt: nowIso()
}

const defaultSettings: Settings = {
  userId: 'local', defaultIsStudy: true, defaultSectionId: '00000000-0000-0000-0000-000000000003', defaultTimerHours: 0, defaultTimerMinutes: 25,
  autoDeletePeriod: 7, dailyNotificationTime: '07:00', notificationEnabled: true, sortOption: 'custom', theme: 'mint', updatedAt: nowIso()
}

let realtimeCleanup: (()=>void) | null = null

const defaultTimer: TimerState = {
  userId: 'local', activeTaskId: null, isRunning: false, hasStarted: false, mode: 'timer', startedAt: null,
  accumulatedSeconds: 0, totalDurationSeconds: 1500, updatedAt: nowIso(), revision: 0, updatedByDeviceId: deviceId
}

interface StoreState {
  ready: boolean
  connected: boolean
  userId: string
  authEmail: string | null
  currentView: ViewName
  tasks: Task[]
  sections: Section[]
  profile: Profile
  settings: Settings
  timer: TimerState
  drawerOpen: boolean
  taskEditorOpen: boolean
  editingTaskId: string | null
  initialTaskDate: string | null
  actionTaskId: string | null
  importOpen: boolean
  toast: string | null
  confettiKey: number
  syncMessage: string

  init: () => Promise<void>
  signIn: (email: string, password: string) => Promise<string | null>
  signUp: (email: string, password: string) => Promise<string | null>
  signOut: () => Promise<void>
  setView: (view: ViewName) => void
  setDrawer: (open: boolean) => void
  openAdd: (date?: Date) => void
  openEdit: (task: Task) => void
  closeEditor: () => void
  setActionTask: (id: string | null) => void
  createTask: (input: Partial<Task> & Pick<Task, 'name' | 'sectionId' | 'startAt' | 'endAt'>) => Promise<void>
  updateTask: (id: string, patch: Partial<Task>, applyToSeries?: boolean) => Promise<void>
  deleteTask: (id: string, mode?: 'one' | 'following' | 'all') => Promise<void>
  completeTask: (id: string) => Promise<void>
  restoreTask: (id: string) => Promise<void>
  deleteCompletedTask: (id: string) => Promise<void>
  deleteAllCompleted: () => Promise<void>
  cleanupCompleted: () => Promise<void>
  addSection: (name: string) => Promise<void>
  renameSection: (id: string, name: string) => Promise<void>
  deleteSection: (id: string) => Promise<void>
  reorderSections: (ids: string[]) => Promise<void>
  updateSettings: (patch: Partial<Settings>) => Promise<void>
  updateProfile: (patch: Partial<Profile>) => Promise<void>
  changeTheme: (theme: ThemeName) => Promise<void>
  reorderTask: (dragId: string, targetId: string | null, targetDate?: Date) => Promise<void>
  batchMove: (ids: string[], date: Date) => Promise<void>
  prepareTimer: (task: Task) => Promise<void>
  toggleTimer: () => Promise<void>
  finishTimer: (complete: boolean) => Promise<void>
  cancelTimer: () => Promise<void>
  setTimerMode: (mode: 'timer' | 'stopwatch') => Promise<void>
  setTimerDuration: (hours: number, minutes: number) => Promise<void>
  currentElapsed: () => number
  currentRemaining: () => number
  streak: () => number
  exportJson: () => void
  importJson: (file: File) => Promise<string | null>
  notify: (message: string) => void
  loadCloud: (userId: string) => Promise<void>
  subscribeRealtime: (userId: string) => void
  persistTask: (task: Task) => Promise<void>
  persistSection: (section: Section) => Promise<void>
  persistTimer: (timer: TimerState) => Promise<void>
}

async function loadLocal(): Promise<{tasks: Task[]; sections: Section[]; profile: Profile; settings: Settings; timer: TimerState} | null> {
  return idbGet('snapshot')
}

async function saveLocal(state: Pick<StoreState, 'tasks' | 'sections' | 'profile' | 'settings' | 'timer'>) {
  await idbSet('snapshot', { tasks: state.tasks, sections: state.sections, profile: state.profile, settings: state.settings, timer: state.timer })
}

function mapTask(row: any): Task {
  return {
    id: row.id, userId: row.user_id, seriesId: row.series_id ?? null, name: row.name, memo: row.memo ?? '', sectionId: row.section_id,
    startAt: row.start_at, endAt: row.end_at, isStudy: row.is_study, isCompleted: row.is_completed, isHidden: row.is_hidden,
    completedAt: row.completed_at, inProgress: row.in_progress, recurrence: row.recurrence ?? { frequency: 'none', weekDays: [], weekNumbers: [], hasEndDate: false, endDate: null },
    createdAt: row.created_at, updatedAt: row.updated_at, customOrder: Number(row.custom_order ?? 0), isDailyCleared: row.is_daily_cleared ?? false, version: Number(row.version ?? 1)
  }
}
function taskRow(task: Task) {
  return {
    id: task.id, user_id: task.userId, series_id: task.seriesId, name: task.name, memo: task.memo, section_id: task.sectionId,
    start_at: task.startAt, end_at: task.endAt, is_study: task.isStudy, is_completed: task.isCompleted, is_hidden: task.isHidden,
    completed_at: task.completedAt, in_progress: task.inProgress, recurrence: task.recurrence, custom_order: task.customOrder,
    is_daily_cleared: task.isDailyCleared, version: task.version, updated_at: task.updatedAt
  }
}

export const useTaskutoStore = create<StoreState>((set, get) => ({
  ready: false, connected: false, userId: 'local', authEmail: null, currentView: 'daily', tasks: [], sections: defaultSections,
  profile: defaultProfile, settings: defaultSettings, timer: defaultTimer, drawerOpen: false, taskEditorOpen: false,
  editingTaskId: null, initialTaskDate: null, actionTaskId: null, importOpen: false, toast: null, confettiKey: 0,
  syncMessage: 'ローカルモード',

  init: async () => {
    if (!hasSupabaseConfig || !supabase) {
      const local = await loadLocal()
      if (local) set({ ...local, ready: true, connected: false, syncMessage: 'ローカルモード' })
      else {
        const today = new Date()
        const demoTasks = [
          defaultTask('数学 青チャート', '00000000-0000-0000-0000-000000000001', today, 'P10〜15', true),
          defaultTask('明日の準備', '00000000-0000-0000-0000-000000000002', addDays(today, 1), '', false, 'daily')
        ]
        set({ tasks: demoTasks, sections: defaultSections, profile: defaultProfile, settings: defaultSettings, timer: defaultTimer, ready: true, connected: false, syncMessage: 'ローカルモード' })
        await saveLocal({ tasks: demoTasks, sections: defaultSections, profile: defaultProfile, settings: defaultSettings, timer: defaultTimer })
      }
      await get().cleanupCompleted()
      return
    }
    const { data: sessionData } = await supabase.auth.getSession()
    const session = sessionData.session
    if (!session) {
      set({ ready: true, connected: true, userId: 'anonymous', syncMessage: 'ログイン待ち' })
      return
    }
    const userId = session.user.id
    set({ userId, authEmail: session.user.email ?? null, connected: true, syncMessage: '同期中…' })
    await get().loadCloud(userId)
    get().subscribeRealtime(userId)
    await get().cleanupCompleted()
  },

  signIn: async (email, password) => {
    if (!supabase) return 'Supabase未設定です。'
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    return error?.message ?? null
  },

  signUp: async (email, password) => {
    if (!supabase) return 'Supabase未設定です。'
    const { error } = await supabase.auth.signUp({ email, password })
    return error?.message ?? null
  },

  signOut: async () => {
    if (supabase) await supabase.auth.signOut()
    set({ authEmail: null, userId: 'anonymous', syncMessage: 'ログアウト済み' })
  },

  setView: view => set({ currentView: view, drawerOpen: false }),
  setDrawer: drawerOpen => set({ drawerOpen }),
  openAdd: date => set({ taskEditorOpen: true, editingTaskId: null, initialTaskDate: (date ?? new Date()).toISOString() }),
  openEdit: task => set({ taskEditorOpen: true, editingTaskId: task.id, initialTaskDate: null, actionTaskId: null }),
  closeEditor: () => set({ taskEditorOpen: false, editingTaskId: null, initialTaskDate: null }),
  setActionTask: id => set({ actionTaskId: id }),

  createTask: async input => {
    const now = nowIso()
    const task: Task = {
      id: input.id ?? crypto.randomUUID(), userId: get().userId, seriesId: input.seriesId ?? ((input.recurrence?.frequency ?? 'none') !== 'none' ? crypto.randomUUID() : null),
      name: input.name, memo: input.memo ?? '', sectionId: input.sectionId, startAt: input.startAt, endAt: input.endAt, isStudy: input.isStudy ?? get().settings.defaultIsStudy,
      isCompleted: false, isHidden: false, completedAt: null, inProgress: false,
      recurrence: input.recurrence ?? { frequency: 'none', weekDays: [], weekNumbers: [], hasEndDate: false, endDate: null },
      createdAt: now, updatedAt: now, customOrder: input.customOrder ?? ((Math.max(0, ...get().tasks.map(t => t.customOrder)) || 0) + 100),
      isDailyCleared: false, version: 1
    }
    set(state => ({ tasks: [...state.tasks, task] }))
    await get().persistTask(task)
  },

  updateTask: async (id, patch, applyToSeries = false) => {
    const target = get().tasks.find(t => t.id === id)
    if (!target) return
    const updated: Task = { ...target, ...patch, updatedAt: nowIso(), version: target.version + 1 }
    const seriesId = target.seriesId
    set(state => ({ tasks: state.tasks.map(t => {
      if (t.id === id) return updated
      if (applyToSeries && seriesId && t.seriesId === seriesId && !t.isCompleted && new Date(t.startAt) >= new Date(target.startAt)) {
        return { ...t, name: updated.name, memo: updated.memo, sectionId: updated.sectionId, isStudy: updated.isStudy, recurrence: updated.recurrence, updatedAt: updated.updatedAt, version: t.version + 1 }
      }
      return t
    }) }))
    await get().persistTask(updated)
    if (applyToSeries && seriesId) {
      const siblings = get().tasks.filter(t => t.seriesId === seriesId && t.id !== id && !t.isCompleted)
      for (const sibling of siblings) await get().persistTask(sibling)
    }
  },

  deleteTask: async (id, mode = 'one') => {
    const target = get().tasks.find(t => t.id === id)
    if (!target) return
    let remaining = get().tasks
    if (mode === 'all' && target.seriesId) remaining = remaining.filter(t => t.seriesId !== target.seriesId)
    else if (mode === 'following' && target.seriesId) remaining = remaining.filter(t => !(t.seriesId === target.seriesId && new Date(t.startAt) >= new Date(target.startAt)))
    else remaining = remaining.filter(t => t.id !== id)
    const removedIds = get().tasks.filter(t => !remaining.some(r => r.id === t.id)).map(t => t.id)
    set({ tasks: remaining })
    await saveLocal({tasks: remaining, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
    if (supabase && get().connected && get().userId !== 'anonymous') {
      if (removedIds.length) await supabase.from('tasks').delete().in('id', removedIds)
    }
  },

  completeTask: async id => {
    const target = get().tasks.find(t => t.id === id)
    if (!target || target.isCompleted) return
    const updated = { ...target, isCompleted: true, inProgress: false, completedAt: nowIso(), updatedAt: nowIso(), version: target.version + 1 }
    set(state => ({ tasks: state.tasks.map(t => t.id === id ? updated : t) }))
    await get().persistTask(updated)

    let nextTask = generateNextRecurring(updated, get().tasks)
    if (nextTask) {
      nextTask = { ...nextTask, userId: get().userId }
      set(state => ({ tasks: [...state.tasks, nextTask], confettiKey: state.confettiKey + (allTasksForDayComplete(state.tasks, updated.endAt) ? 1 : 0) }))
      await get().persistTask(nextTask)
    } else if (allTasksForDayComplete(get().tasks, updated.endAt)) set(state => ({ confettiKey: state.confettiKey + 1 }))
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
  },

  restoreTask: async id => {
    const target = get().tasks.find(t => t.id === id)
    if (!target) return
    const updated = { ...target, isCompleted: false, isHidden: false, inProgress: false, completedAt: null, isDailyCleared: false, updatedAt: nowIso(), version: target.version + 1 }
    set(state => ({ tasks: state.tasks.map(t => t.id === id ? updated : t) }))
    await get().persistTask(updated)
  },

  deleteCompletedTask: async id => get().deleteTask(id, 'one'),
  deleteAllCompleted: async () => {
    const ids = get().tasks.filter(t => t.isCompleted).map(t => t.id)
    set(state => ({ tasks: state.tasks.filter(t => !t.isCompleted) }))
    if (supabase && get().connected && ids.length) await supabase.from('tasks').delete().in('id', ids)
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
  },
  cleanupCompleted: async () => {
    const cutoff = Date.now() - get().settings.autoDeletePeriod * 86_400_000
    const oldIds = get().tasks.filter(t => t.isCompleted && t.completedAt && new Date(t.completedAt).getTime() <= cutoff).map(t => t.id)
    if (!oldIds.length) return
    set(state => ({ tasks: state.tasks.filter(t => !oldIds.includes(t.id)) }))
    if (supabase && get().connected) await supabase.from('tasks').delete().in('id', oldIds)
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
  },

  addSection: async name => {
    const clean = name.trim()
    if (!clean || get().sections.some(s => s.name === clean)) return
    const now = nowIso()
    const section = { id: crypto.randomUUID(), userId: get().userId, name: clean, sortOrder: get().sections.length, createdAt: now, updatedAt: now }
    set(state => ({ sections: [...state.sections, section] }))
    await get().persistSection(section)
  },
  renameSection: async (id, name) => {
    if (id === '00000000-0000-0000-0000-000000000000' || id === '00000000-0000-0000-0000-000000000003') return
    const clean = name.trim()
    if (!clean) return
    const target = get().sections.find(s => s.id === id)
    if (!target) return
    const updated = { ...target, name: clean, updatedAt: nowIso() }
    set(state => ({ sections: state.sections.map(s => s.id === id ? updated : s) }))
    await get().persistSection(updated)
  },
  deleteSection: async id => {
    if (id === '00000000-0000-0000-0000-000000000000' || id === '00000000-0000-0000-0000-000000000003') return
    const fallback = get().sections.find(s => s.name === '未分類')!.id
    set(state => ({ sections: state.sections.filter(s => s.id !== id), tasks: state.tasks.map(t => t.sectionId === id ? { ...t, sectionId: fallback, updatedAt: nowIso(), version: t.version + 1 } : t) }))
    const changed = get().tasks.filter(t => t.sectionId === fallback)
    for (const task of changed) await get().persistTask(task)
    if (supabase && get().connected) await supabase.from('sections').delete().eq('id', id)
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
  },
  reorderSections: async ids => {
    set(state => ({ sections: ids.map((id, i) => ({ ...state.sections.find(s => s.id === id)!, sortOrder: i, updatedAt: nowIso() })) }))
    for (const section of get().sections) if (section.name !== '全て') await get().persistSection(section)
  },

  updateSettings: async patch => {
    const settings = { ...get().settings, ...patch, updatedAt: nowIso() }
    set({ settings })
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings, timer:get().timer})
    if (supabase && get().connected) await supabase.from('settings').upsert(settingsRow(settings), { onConflict: 'user_id' })
  },
  updateProfile: async patch => {
    const profile = { ...get().profile, ...patch, updatedAt: nowIso() }
    set({ profile })
    await saveLocal({tasks:get().tasks, sections:get().sections, profile, settings:get().settings, timer:get().timer})
    if (supabase && get().connected) await supabase.from('profiles').upsert(profileRow(profile), { onConflict: 'id' })
  },
  changeTheme: async theme => get().updateSettings({ theme }),

  reorderTask: async (dragId, targetId, targetDate) => {
    const tasks = [...get().tasks]
    const drag = tasks.find(t => t.id === dragId)
    if (!drag) return
    if (targetDate) {
      const base = new Date(drag.startAt)
      const next = new Date(targetDate)
      const duration = getDurationDays(drag)
      next.setHours(12,0,0,0)
      const moved = { ...drag, startAt: next.toISOString(), endAt: addDays(next, duration).toISOString(), updatedAt: nowIso(), version: drag.version + 1 }
      const others = tasks.filter(t => t.id !== dragId)
      const sameDayTasks = others.filter(t => t.sectionId === drag.sectionId && !t.isCompleted && !t.isHidden && sameDay(t.startAt, next))
      moved.customOrder = targetId ? (sameDayTasks.find(t => t.id === targetId)?.customOrder ?? 0) - 0.5 : ((Math.max(0, ...sameDayTasks.map(t => t.customOrder)) || 0) + 100)
      set({ tasks: [...others, moved] })
      await get().persistTask(moved)
    } else if (targetId && dragId !== targetId) {
      const target = tasks.find(t => t.id === targetId)
      if (!target || drag.sectionId !== target.sectionId || !sameDay(drag.startAt, target.startAt)) return
      const peers = tasks.filter(t => t.sectionId === drag.sectionId && sameDay(t.startAt, drag.startAt) && !t.isCompleted && !t.isHidden && t.id !== dragId).sort((a,b)=>a.customOrder-b.customOrder)
      const index = peers.findIndex(t => t.id === targetId)
      peers.splice(Math.max(0,index), 0, drag)
      const reordered = tasks.map(t => {
        const i = peers.findIndex(p => p.id === t.id)
        return i >= 0 ? { ...t, customOrder: (i+1)*100, updatedAt: nowIso(), version: t.version + 1 } : t
      })
      set({ tasks: reordered })
      for (const t of peers) await get().persistTask(reordered.find(x=>x.id===t.id)!)
    }
  },

  batchMove: async (ids, date) => {
    const nextTasks = get().tasks.map(t => ids.includes(t.id) ? { ...t, startAt: new Date(date).toISOString(), endAt: new Date(date).toISOString(), updatedAt: nowIso(), version: t.version + 1 } : t)
    set({ tasks: nextTasks })
    for (const t of nextTasks.filter(t => ids.includes(t.id))) await get().persistTask(t)
  },

  prepareTimer: async task => {
    const timer: TimerState = { ...get().timer, userId:get().userId, activeTaskId:task.id, isRunning:false, hasStarted:false, mode:get().timer.mode, startedAt:null,
      accumulatedSeconds:0, totalDurationSeconds:(get().settings.defaultTimerHours*3600)+(get().settings.defaultTimerMinutes*60), updatedAt:nowIso(), revision:get().timer.revision+1, updatedByDeviceId:deviceId }
    set({ timer })
    await get().persistTimer(timer)
    if (task.isStudy) launchShortcut('勉強開始')
  },
  toggleTimer: async () => {
    const timer = get().timer
    if (!timer.activeTaskId) return
    if (timer.isRunning) {
      const elapsed = get().currentElapsed()
      const next: TimerState = { ...timer, isRunning:false, startedAt:null, accumulatedSeconds:elapsed, updatedAt:nowIso(), revision:timer.revision+1, updatedByDeviceId:deviceId }
      set({ timer: next })
      await get().persistTimer(next)
      const task = get().tasks.find(t=>t.id===timer.activeTaskId)
      if (task?.isStudy) launchShortcut('勉強中断')
    } else {
      const next: TimerState = { ...timer, isRunning:true, hasStarted:true, startedAt:nowIso(), updatedAt:nowIso(), revision:timer.revision+1, updatedByDeviceId:deviceId }
      set({ timer: next })
      await get().persistTimer(next)
      const task = get().tasks.find(t=>t.id===timer.activeTaskId)
      if (task?.isStudy && timer.hasStarted) launchShortcut('勉強再開')
      if (task) { const startedTask={...task,inProgress:true,updatedAt:nowIso(),version:task.version+1}; set(state=>({tasks:state.tasks.map(t=>t.id===task.id?startedTask:t)})); await get().persistTask(startedTask) }
    }
  },
  finishTimer: async complete => {
    const timer = get().timer
    const task = timer.activeTaskId ? get().tasks.find(t=>t.id===timer.activeTaskId) : null
    if (task && task.isStudy) launchShortcut('勉強終了')
    if (complete && task) await get().completeTask(task.id)
    else if (task) set(state=>({tasks:state.tasks.map(t=>t.id===task.id?{...t,inProgress:false}:t)}))
    const next = { ...defaultTimer, userId:get().userId, totalDurationSeconds:(get().settings.defaultTimerHours*3600)+(get().settings.defaultTimerMinutes*60), revision:timer.revision+1, updatedByDeviceId:deviceId, updatedAt:nowIso() }
    set({ timer: next })
    await get().persistTimer(next)
  },
  cancelTimer: async () => {
    const timer = get().timer
    const task = timer.activeTaskId ? get().tasks.find(t=>t.id===timer.activeTaskId) : null
    if (task?.isStudy) launchShortcut('勉強中止')
    if (task) set(state=>({tasks:state.tasks.map(t=>t.id===task.id?{...t,inProgress:false}:t)}))
    const next = { ...defaultTimer, userId:get().userId, totalDurationSeconds:(get().settings.defaultTimerHours*3600)+(get().settings.defaultTimerMinutes*60), revision:timer.revision+1, updatedByDeviceId:deviceId, updatedAt:nowIso() }
    set({ timer:next }); await get().persistTimer(next)
  },
  setTimerMode: async mode => { const timer={...get().timer, mode, totalDurationSeconds:get().timer.hasStarted?get().timer.totalDurationSeconds:(get().settings.defaultTimerHours*3600)+(get().settings.defaultTimerMinutes*60), updatedAt:nowIso(), revision:get().timer.revision+1, updatedByDeviceId:deviceId}; set({timer}); await get().persistTimer(timer) },
  setTimerDuration: async (hours, minutes) => { const timer={...get().timer, totalDurationSeconds:hours*3600+minutes*60, updatedAt:nowIso(), revision:get().timer.revision+1, updatedByDeviceId:deviceId}; set({timer}); await get().persistTimer(timer) },
  currentElapsed: () => {
    const t=get().timer
    if (!t.isRunning || !t.startedAt) return Math.floor(t.accumulatedSeconds)
    return Math.floor(t.accumulatedSeconds + (Date.now()-new Date(t.startedAt).getTime())/1000)
  },
  currentRemaining: () => Math.max(0, Math.ceil(get().timer.totalDurationSeconds-get().currentElapsed())),
  streak: () => calculateStreak(get().tasks),

  exportJson: () => {
    const blob = new Blob([JSON.stringify({ tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings }, null, 2)], {type:'application/json'})
    const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='taskuto-backup.json'; a.click(); URL.revokeObjectURL(a.href)
  },
  importJson: async file => {
    try {
      const parsed = JSON.parse(await file.text())
      const bareTasks = Array.isArray(parsed) ? parsed : Array.isArray(parsed.tasks) ? parsed.tasks : null
      if (!bareTasks) return 'JSONの形式がTAsKUTOのバックアップと一致しません。'
      const sectionByName = new Map<string, Section>(); for (const existing of get().sections) sectionByName.set(existing.name, existing)
      const epoch2001 = 978307200
      const swiftDate = (value:any, fallback=Date.now()) => {
        if (typeof value === 'number') return new Date((value + epoch2001)*1000).toISOString()
        if (typeof value === 'string') return value
        return new Date(fallback).toISOString()
      }
      const frequencyMap:any = {'なし':'none','毎日':'daily','毎週':'weekly','毎月':'monthly',none:'none',daily:'daily',weekly:'weekly',monthly:'monthly'}
      const imported:Task[] = []
      for (const raw of bareTasks) {
        const name=String(raw.name??'無題のタスク'); const sectionName=String(raw.section??'未分類')
        if(!sectionByName.has(sectionName)){const now=nowIso();const section={id:crypto.randomUUID(),userId:get().userId,name:sectionName,sortOrder:get().sections.length,createdAt:now,updatedAt:now};sectionByName.set(sectionName,section);set(state=>({sections:[...state.sections,section]}));await get().persistSection(section)}
        const sec=sectionByName.get(sectionName)!
        const recurrenceRaw=raw.recurrence??{}
        const freq=frequencyMap[recurrenceRaw.frequency]??'none'
        const startAt=swiftDate(raw.startDate??raw.dueDate); const endAt=swiftDate(raw.endDate??raw.dueDate, new Date(startAt).getTime())
        const now=nowIso()
        imported.push({id:typeof raw.id==='string'?raw.id:crypto.randomUUID(),userId:get().userId,seriesId:freq==='none'?null:crypto.randomUUID(),name,memo:String(raw.memo??''),sectionId:sec.id,startAt,endAt,isStudy:Boolean(raw.isStudy),isCompleted:Boolean(raw.isCompleted),isHidden:Boolean(raw.isHidden),completedAt:raw.completedAt==null?null:swiftDate(raw.completedAt),inProgress:Boolean(raw.inProgress),recurrence:{frequency:freq,weekDays:Array.isArray(recurrenceRaw.weekDays)?recurrenceRaw.weekDays.map(Number):[],weekNumbers:Array.isArray(recurrenceRaw.weekNumbers)?recurrenceRaw.weekNumbers.map(Number):[],hasEndDate:Boolean(recurrenceRaw.hasEndDate),endDate:recurrenceRaw.endDate==null?null:swiftDate(recurrenceRaw.endDate)},createdAt:raw.createdAt==null?now:swiftDate(raw.createdAt),updatedAt:now,customOrder:Number(raw.customOrder??0),isDailyCleared:Boolean(raw.isDailyCleared??false),version:1})
      }
      set({ tasks: imported, profile: Array.isArray(parsed)?get().profile:parsed.profile ?? get().profile, settings:Array.isArray(parsed)?get().settings:parsed.settings ?? get().settings })
      for (const task of imported) await get().persistTask(task)
      await saveLocal({tasks:imported, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
      return null
    } catch (error) { return `JSONファイルを読み込めませんでした。${error instanceof Error?` ${error.message}`:''}` }
  },
  notify: message => { set({toast:message}); window.setTimeout(()=>set({toast:null}), 2600) },

  loadCloud: async userId => {
    if (!supabase) return
    const [tasksR, sectionsR, profileR, settingsR, timerR] = await Promise.all([
      supabase.from('tasks').select('*').eq('user_id', userId),
      supabase.from('sections').select('*').eq('user_id', userId).order('sort_order'),
      supabase.from('profiles').select('*').eq('id', userId).maybeSingle(),
      supabase.from('settings').select('*').eq('user_id', userId).maybeSingle(),
      supabase.from('timer_state').select('*').eq('user_id', userId).maybeSingle()
    ])
    const sections = sectionsR.data?.length ? sectionsR.data.map((r:any)=>({id:r.id,userId:r.user_id,name:r.name,sortOrder:r.sort_order,createdAt:r.created_at,updatedAt:r.updated_at})) : defaultSections
    const settings = settingsR.data ? mapSettings(settingsR.data, userId) : {...defaultSettings,userId}
    const profile = profileR.data ? mapProfile(profileR.data) : {...defaultProfile,id:userId}
    const timer = timerR.data ? mapTimer(timerR.data) : {...defaultTimer,userId}
    const tasks = (tasksR.data ?? []).map(mapTask)
    set({tasks, sections, settings, profile, timer, ready:true, authEmail:get().authEmail, syncMessage:'オンライン同期'})
    await saveLocal({tasks,sections,profile,settings,timer})
    if (!profileR.data) await supabase.from('profiles').upsert(profileRow(profile))
    if (!settingsR.data) await supabase.from('settings').upsert(settingsRow(settings))
    if (!timerR.data) await supabase.from('timer_state').upsert(timerRow(timer))
    if (!sectionsR.data?.length) for(const section of sections.filter(s=>s.name!=='全て')) await supabase.from('sections').upsert(sectionRow(section,userId))
    // Keep generated data in the cloud if a first-run account starts empty.
  },
  subscribeRealtime: userId => {
    if (!supabase) return
    realtimeCleanup?.()
    const channel = supabase.channel(`taskuto:${userId}`)
      .on('postgres_changes',{event:'*',schema:'public',table:'tasks',filter:`user_id=eq.${userId}`},payload=>{
        if (payload.eventType==='DELETE') set(state=>({tasks:state.tasks.filter(t=>t.id!==(payload.old as any).id)}))
        else {
          const incoming=mapTask(payload.new)
          set(state=>({tasks: state.tasks.some(t=>t.id===incoming.id) ? state.tasks.map(t=>t.id===incoming.id ? (new Date(incoming.updatedAt)>new Date(t.updatedAt)?incoming:t) : t) : [...state.tasks,incoming]}))
        }
      })
      .on('postgres_changes',{event:'*',schema:'public',table:'sections',filter:`user_id=eq.${userId}`},payload=>{
        if(payload.eventType==='DELETE') set(state=>({sections:state.sections.filter(s=>s.id!==(payload.old as any).id)}))
        else { const r:any=payload.new; const s={id:r.id,userId:r.user_id,name:r.name,sortOrder:r.sort_order,createdAt:r.created_at,updatedAt:r.updated_at}; set(state=>({sections:state.sections.some(x=>x.id===s.id)?state.sections.map(x=>x.id===s.id?s:x):[...state.sections,s]})) }
      })
      .on('postgres_changes',{event:'*',schema:'public',table:'settings',filter:`user_id=eq.${userId}`},payload=>{ if(payload.eventType!=='DELETE') set({settings:mapSettings(payload.new,userId)}) })
      .on('postgres_changes',{event:'*',schema:'public',table:'profiles',filter:`id=eq.${userId}`},payload=>{ if(payload.eventType!=='DELETE') set({profile:mapProfile(payload.new)}) })
      .on('postgres_changes',{event:'*',schema:'public',table:'timer_state',filter:`user_id=eq.${userId}`},payload=>{ if(payload.eventType!=='DELETE') { const incoming=mapTimer(payload.new); if(incoming.updatedByDeviceId!==deviceId) set({timer:incoming}) } })
      .subscribe(() => set({syncMessage:'オンライン同期'}))
    realtimeCleanup = () => { void supabase.removeChannel(channel) }
  },

  persistTask: async task => {
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
    if (supabase && get().connected && get().userId !== 'anonymous') await supabase.from('tasks').upsert(taskRow({...task,userId:get().userId}),{onConflict:'id'})
  },
  persistSection: async section => {
    if (section.name === '全て') return
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings, timer:get().timer})
    if (supabase && get().connected && get().userId !== 'anonymous') await supabase.from('sections').upsert(sectionRow({...section,userId:get().userId},get().userId),{onConflict:'id'})
  },
  persistTimer: async timer => {
    await saveLocal({tasks:get().tasks, sections:get().sections, profile:get().profile, settings:get().settings, timer})
    if (supabase && get().connected && get().userId !== 'anonymous') await supabase.from('timer_state').upsert(timerRow({...timer,userId:get().userId}),{onConflict:'user_id'})
  }
}))

function allTasksForDayComplete(tasks: Task[], endAt: string) {
  const day = startOfDay(new Date(endAt)).getTime()
  const dayTasks = tasks.filter(t=>!t.isHidden && startOfDay(new Date(t.endAt)).getTime()===day)
  return dayTasks.length>0 && dayTasks.every(t=>t.isCompleted)
}

function generateNextRecurring(task: Task, tasks: Task[]): Task | null {
  if (task.recurrence.frequency === 'none') return null
  const nextStart = calculateNextDate(new Date(task.startAt), task.recurrence)
  if (!nextStart) return null
  if (task.recurrence.hasEndDate && task.recurrence.endDate && startOfDay(nextStart)>startOfDay(new Date(task.recurrence.endDate))) return null
  const exists = tasks.some(t=>!t.isHidden && t.name===task.name && sameDay(t.startAt,nextStart) && (t.seriesId===task.seriesId || task.seriesId===null))
  return exists ? null : cloneNextRecurringTask(task,nextStart)
}

function mapProfile(r:any): Profile { return {id:r.id,displayName:r.display_name ?? '赤木 拓斗',avatarUrl:r.avatar_url ?? null,timezone:r.timezone ?? 'Asia/Tokyo',createdAt:r.created_at,updatedAt:r.updated_at} }
function profileRow(p:Profile){ return {id:p.id,display_name:p.displayName,avatar_url:p.avatarUrl,timezone:p.timezone,created_at:p.createdAt,updated_at:p.updatedAt} }
function mapSettings(r:any,userId:string):Settings{ return {userId,defaultIsStudy:r.default_is_study,defaultSectionId:r.default_section_id,defaultTimerHours:r.default_timer_hours,defaultTimerMinutes:r.default_timer_minutes,autoDeletePeriod:r.auto_delete_period,dailyNotificationTime:r.daily_notification_time,notificationEnabled:r.notification_enabled,sortOption:r.sort_option,theme:r.theme,updatedAt:r.updated_at} }
function settingsRow(s:Settings){ return {user_id:s.userId,default_is_study:s.defaultIsStudy,default_section_id:s.defaultSectionId,default_timer_hours:s.defaultTimerHours,default_timer_minutes:s.defaultTimerMinutes,auto_delete_period:s.autoDeletePeriod,daily_notification_time:s.dailyNotificationTime,notification_enabled:s.notificationEnabled,sort_option:s.sortOption,theme:s.theme,updated_at:s.updatedAt} }
function mapTimer(r:any):TimerState{return {userId:r.user_id,activeTaskId:r.active_task_id,isRunning:r.is_running,hasStarted:r.has_started,mode:r.mode,startedAt:r.started_at,accumulatedSeconds:Number(r.accumulated_seconds??0),totalDurationSeconds:Number(r.total_duration_seconds??1500),updatedAt:r.updated_at,revision:Number(r.revision??0),updatedByDeviceId:r.updated_by_device_id??''}}
function timerRow(t:TimerState){return {user_id:t.userId,active_task_id:t.activeTaskId,is_running:t.isRunning,has_started:t.hasStarted,mode:t.mode,started_at:t.startedAt,accumulated_seconds:t.accumulatedSeconds,total_duration_seconds:t.totalDurationSeconds,updated_at:t.updatedAt,revision:t.revision,updated_by_device_id:t.updatedByDeviceId}}
function sectionRow(s:Section,userId:string){return {id:s.id,user_id:userId,name:s.name,sort_order:s.sortOrder,created_at:s.createdAt,updated_at:s.updatedAt}}
function launchShortcut(name:string){
  if(!('ontouchstart' in window)) return
  const encoded=encodeURIComponent(name)
  window.location.href=`shortcuts://run-shortcut?name=${encoded}`
}
