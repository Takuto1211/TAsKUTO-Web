export type ThemeName =
  | 'mint' | 'blue' | 'pink' | 'lavender' | 'lemon'
  | 'peach' | 'ocean' | 'sunset' | 'forest' | 'monochrome'

export type Frequency = 'none' | 'daily' | 'weekly' | 'monthly'
export type SortOption = 'nameAsc' | 'nameDesc' | 'createdAtAsc' | 'createdAtDesc' | 'custom'
export type ViewName = 'daily' | 'tasks' | 'completed' | 'settings'

export interface RecurrenceSettings {
  frequency: Frequency
  weekDays: number[]
  weekNumbers: number[]
  hasEndDate: boolean
  endDate: string | null
}

export interface Task {
  id: string
  userId?: string
  seriesId: string | null
  name: string
  memo: string
  sectionId: string
  startAt: string
  endAt: string
  isStudy: boolean
  isCompleted: boolean
  isHidden: boolean
  completedAt: string | null
  inProgress: boolean
  recurrence: RecurrenceSettings
  createdAt: string
  updatedAt: string
  customOrder: number
  isDailyCleared: boolean
  version: number
}

export interface Section {
  id: string
  userId?: string
  name: string
  sortOrder: number
  createdAt: string
  updatedAt: string
}

export interface Profile {
  id: string
  displayName: string
  avatarUrl: string | null
  timezone: string
  createdAt: string
  updatedAt: string
}

export interface Settings {
  userId: string
  defaultIsStudy: boolean
  defaultSectionId: string
  defaultTimerHours: number
  defaultTimerMinutes: number
  autoDeletePeriod: number
  dailyNotificationTime: string
  notificationEnabled: boolean
  sortOption: SortOption
  theme: ThemeName
  updatedAt: string
}

export interface TimerState {
  userId: string
  activeTaskId: string | null
  isRunning: boolean
  hasStarted: boolean
  mode: 'timer' | 'stopwatch'
  startedAt: string | null
  accumulatedSeconds: number
  totalDurationSeconds: number
  updatedAt: string
  revision: number
  updatedByDeviceId: string
}

export interface Snapshot {
  tasks: Task[]
  sections: Section[]
  profile: Profile
  settings: Settings
  timer: TimerState
}

export interface ThemeTokens {
  accent: string
  accent2: string
  lightBg: string
  darkBg: string
  glow: string
}
