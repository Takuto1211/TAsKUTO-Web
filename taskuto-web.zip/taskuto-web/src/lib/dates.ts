import type { RecurrenceSettings, Task } from './types'

export const JAPANESE_WEEKDAYS = ['日', '月', '火', '水', '木', '金', '土']

export function startOfDay(date: Date): Date {
  const d = new Date(date)
  d.setHours(0, 0, 0, 0)
  return d
}

export function addDays(date: Date, amount: number): Date {
  const d = new Date(date)
  d.setDate(d.getDate() + amount)
  return d
}

export function addMonths(date: Date, amount: number): Date {
  const d = new Date(date)
  d.setMonth(d.getMonth() + amount)
  return d
}

export function sameDay(a: Date | string, b: Date | string): boolean {
  return startOfDay(new Date(a)).getTime() === startOfDay(new Date(b)).getTime()
}

export function formatDay(date: Date | string): string {
  return new Intl.DateTimeFormat('ja-JP', { month: 'numeric', day: 'numeric', weekday: 'short' }).format(new Date(date))
}

export function formatMonthDay(date: Date | string): string {
  return new Intl.DateTimeFormat('ja-JP', { month: 'numeric', day: 'numeric', weekday: 'short' }).format(new Date(date))
}

export function formatDateTime(date: Date | string): string {
  return new Intl.DateTimeFormat('ja-JP', { month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' }).format(new Date(date))
}

export function toDateInputValue(date: Date | string): string {
  const d = new Date(date)
  const pad = (n: number) => String(n).padStart(2, '0')
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`
}

export function fromDateInputValue(value: string, base = new Date()): string {
  const [year, month, day] = value.split('-').map(Number)
  const d = new Date(base)
  d.setFullYear(year, month - 1, day)
  d.setHours(12, 0, 0, 0)
  return d.toISOString()
}

export function getDurationDays(task: Task): number {
  const start = startOfDay(new Date(task.startAt)).getTime()
  const end = startOfDay(new Date(task.endAt)).getTime()
  return Math.max(0, Math.round((end - start) / 86_400_000))
}

export function isMultiDay(task: Task): boolean {
  return getDurationDays(task) > 0
}

export function isOverdue(task: Task, now = new Date()): boolean {
  return !task.isCompleted && startOfDay(new Date(task.endAt)) < startOfDay(now)
}

export function calculateNextDate(date: Date, rule: RecurrenceSettings): Date | null {
  let nextDate = new Date(date)
  for (let i = 0; i < 366; i += 1) {
    if (rule.frequency === 'daily') nextDate = addDays(nextDate, 1)
    else if (rule.frequency === 'weekly') nextDate = addDays(nextDate, 1)
    else if (rule.frequency === 'monthly') nextDate = addMonths(nextDate, 1)
    else return null

    if (rule.frequency === 'weekly') {
      const weekday = nextDate.getDay() + 1 // Swift Calendar: Sun=1 ... Sat=7
      if (rule.weekDays.length > 0 && !rule.weekDays.includes(weekday)) continue
      if (rule.weekNumbers.length > 0) {
        const weekOfMonth = Math.ceil(nextDate.getDate() / 7)
        if (!rule.weekNumbers.includes(weekOfMonth)) continue
      }
    }
    return nextDate
  }
  return null
}

export function cloneNextRecurringTask(task: Task, nextStart: Date): Task {
  const duration = getDurationDays(task)
  const nextEnd = addDays(nextStart, duration)
  const now = new Date().toISOString()
  return {
    ...task,
    id: crypto.randomUUID(),
    startAt: nextStart.toISOString(),
    endAt: nextEnd.toISOString(),
    isCompleted: false,
    isHidden: false,
    completedAt: null,
    inProgress: false,
    createdAt: now,
    updatedAt: now,
    version: 1
  }
}

export function shouldGenerateNext(task: Task, tasks: Task[]): boolean {
  if (task.recurrence.frequency === 'none') return false
  const next = calculateNextDate(new Date(task.startAt), task.recurrence)
  if (!next) return false
  if (task.recurrence.hasEndDate && task.recurrence.endDate && startOfDay(next) > startOfDay(new Date(task.recurrence.endDate))) return false
  return !tasks.some(t => !t.isHidden && sameDay(t.startAt, next) && t.name === task.name && (t.seriesId === task.seriesId || task.seriesId === null))
}

export function generateNextIfNeeded(task: Task, tasks: Task[]): Task | null {
  if (!shouldGenerateNext(task, tasks)) return null
  const next = calculateNextDate(new Date(task.startAt), task.recurrence)
  if (!next) return null
  return cloneNextRecurringTask(task, next)
}

export function calculateStreak(tasks: Task[], now = new Date()): number {
  const logicalNow = new Date(now.getTime() - 2 * 3_600_000)
  const logicalToday = startOfDay(logicalNow)
  const relevant = tasks.filter(t => !t.isHidden)
  if (relevant.length === 0) return 0

  let minDate: Date | null = null
  for (const task of relevant) {
    const due = startOfDay(new Date(task.endAt))
    if (due <= logicalToday && (!minDate || due < minDate)) minDate = due
  }
  if (!minDate) return 0

  const days: { date: Date; hasTasks: boolean; okByDeadline: boolean; okByNextDeadline: boolean; isToday: boolean }[] = []
  let cursor = new Date(minDate)
  while (cursor <= logicalToday) {
    const dayTasks = relevant.filter(t => sameDay(t.endAt, cursor))
    const isToday = sameDay(cursor, logicalToday)
    if (dayTasks.length === 0) {
      days.push({ date: new Date(cursor), hasTasks: false, okByDeadline: false, okByNextDeadline: false, isToday })
      cursor = addDays(cursor, 1)
      continue
    }
    const deadline = new Date(startOfDay(cursor).getTime() + 26 * 3_600_000)
    const nextDeadline = new Date(startOfDay(cursor).getTime() + 50 * 3_600_000)
    let okByDeadline = true
    let okByNextDeadline = true
    for (const task of dayTasks) {
      if (!task.isCompleted) { okByDeadline = false; okByNextDeadline = false; break }
      if (!task.completedAt) { okByDeadline = false; okByNextDeadline = false; break }
      const completedAt = new Date(task.completedAt)
      if (completedAt > deadline) okByDeadline = false
      if (completedAt > nextDeadline) okByNextDeadline = false
    }
    days.push({ date: new Date(cursor), hasTasks: true, okByDeadline, okByNextDeadline, isToday })
    cursor = addDays(cursor, 1)
  }

  const taskDays = days.filter(d => d.hasTasks)
  let streak = 0
  let i = 0
  while (i < taskDays.length) {
    const current = taskDays[i]
    if (current.okByDeadline) {
      streak += 1
      i += 1
    } else if (i + 1 < taskDays.length) {
      const next = taskDays[i + 1]
      if (current.okByNextDeadline && next.okByDeadline) {
        streak += 2
        i += 2
      } else {
        streak = 0
        i += 1
      }
    } else {
      if (current.isToday) break
      streak = 0
      i += 1
    }
  }
  return streak
}
