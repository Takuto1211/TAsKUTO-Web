import type { ThemeName, ThemeTokens } from './types'

export const THEMES: Record<ThemeName, ThemeTokens> = {
  mint: { accent: '#5ed39c', accent2: '#9ce6c6', lightBg: '#e8faf2', darkBg: '#101918', glow: 'rgba(94,211,156,.34)' },
  blue: { accent: '#5b9ff0', accent2: '#9ec7f5', lightBg: '#e8f4fb', darkBg: '#10171d', glow: 'rgba(91,159,240,.34)' },
  pink: { accent: '#e96c99', accent2: '#f4acc4', lightBg: '#fdeaf2', darkBg: '#1b1117', glow: 'rgba(233,108,153,.34)' },
  lavender: { accent: '#9d75d6', accent2: '#c9b1ee', lightBg: '#f1edfb', darkBg: '#15111e', glow: 'rgba(157,117,214,.34)' },
  lemon: { accent: '#e6c83f', accent2: '#f3dd7c', lightBg: '#fcfbe8', darkBg: '#19180d', glow: 'rgba(230,200,63,.3)' },
  peach: { accent: '#e78268', accent2: '#f1b7a5', lightBg: '#fff0eb', darkBg: '#1b1210', glow: 'rgba(231,130,104,.3)' },
  ocean: { accent: '#39b8e9', accent2: '#92dbf3', lightBg: '#e8f7fc', darkBg: '#0d171b', glow: 'rgba(57,184,233,.34)' },
  sunset: { accent: '#ed873c', accent2: '#f4bc89', lightBg: '#fff0e6', darkBg: '#1b140d', glow: 'rgba(237,135,60,.32)' },
  forest: { accent: '#4bba78', accent2: '#91daa9', lightBg: '#e9f7ee', darkBg: '#0f1813', glow: 'rgba(75,186,120,.32)' },
  monochrome: { accent: '#777b83', accent2: '#aeb1b7', lightBg: '#f0f1f2', darkBg: '#121316', glow: 'rgba(119,123,131,.24)' }
}

export const THEME_LABELS: Record<ThemeName, string> = {
  mint: 'ミントグリーン', blue: 'アイスブルー', pink: 'パステルピンク', lavender: 'ラベンダー', lemon: 'レモンイエロー',
  peach: 'ピーチ', ocean: 'オーシャン', sunset: 'サンセットオレンジ', forest: 'フォレストグリーン', monochrome: 'モノクローム'
}
