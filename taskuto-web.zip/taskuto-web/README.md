# TAsKUTO Web
Swift Playground版TAsKUTOを、iPhone/iPadを最優先に再構築するReact/TypeScript PWAです。

## 1. CodeSandboxで開く
1. CodeSandboxで「Create Sandbox」からReact + Vite系のプロジェクトを作るか、このフォルダをGitHub経由でImportします。
2. 依存関係が自動インストールされたら、Previewを開きます。
3. このプロジェクトはSupabaseの環境変数が未設定でもLOCAL DEMOモードで起動します。

## 2. 複数端末同期を有効にする
1. Supabaseで新規プロジェクトを作成。
2. SQL Editorで `supabase/schema.sql` を全体実行。
3. SupabaseのProject URLとPublishable Keyを取得。
4. CodeSandboxのEnvironment Variablesに以下を設定。
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_PUBLISHABLE_KEY`
5. Previewを再読み込み。
6. TAsKUTO画面でアカウントを作成し、iPhone/iPadから同じアカウントでログインします。

## 3. PWAとしてホーム画面へ
本番ビルドをHTTPSで公開後、iPhone/iPadのSafariからTAsKUTOを開き「ホーム画面に追加」を使います。Manifestはstandalone設定済みです。

## 4. 現在の実装範囲
- 日別91日タイムライン
- 1日タスク/複数日タスク
- タスク追加・編集・削除・完了・復元
- セクション管理
- 毎日/毎週/毎月の繰り返し
- 曜日・第1～5週指定
- 繰り返しの「この日のみ/以降全て」編集基盤
- ドラッグでの日付移動
- 並び替えモード・複数選択・一括移動
- 完了履歴と自動削除
- 10テーマ
- Glass/Liquid Glass風UI
- ストリーク
- 紙吹雪
- タイマー/ストップウォッチ/一時停止/再開/超過
- Supabase Realtime同期
- ローカルIndexedDBキャッシュ
- Swift版JSONバックアップのインポート/エクスポート
- PWA
- iOS Shortcuts URL Scheme起動（タッチ端末でのみ起動）

## 5. 通知
クライアント側の通知許可UIとPWA基盤は入っています。バックグラウンドWeb PushはVAPIDキー、Push subscription保存、Edge Functionの実送信処理を本番環境の認証/セキュリティ設定に合わせて有効化します。

## 6. Swift版JSON
Swift版が生成する `tasks_backup.json` を読み込めるようにするためのインポート導線を用意しています。旧版の `dueDate` を含む形式は必要に応じて変換ロジックを追加してください。

## 注意
現在は「まずCodeSandboxで画面と基本データ処理を触れること」を優先した第1実装です。Realtime DB接続は実際のSupabaseプロジェクト作成後に有効になります。
