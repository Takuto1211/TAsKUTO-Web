-- TAsKUTO Web: Supabase schema
-- Run this once in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '赤木 拓斗',
  avatar_url text,
  timezone text not null default 'Asia/Tokyo',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sections (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, name)
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  series_id uuid,
  name text not null,
  memo text not null default '',
  section_id uuid not null,
  start_at timestamptz not null,
  end_at timestamptz not null,
  is_study boolean not null default false,
  is_completed boolean not null default false,
  is_hidden boolean not null default false,
  completed_at timestamptz,
  in_progress boolean not null default false,
  recurrence jsonb not null default '{"frequency":"none","weekDays":[],"weekNumbers":[],"hasEndDate":false,"endDate":null}'::jsonb,
  custom_order double precision not null default 100,
  is_daily_cleared boolean not null default false,
  version integer not null default 1,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint tasks_time_order check (end_at >= start_at)
);

create index if not exists tasks_user_start_idx on public.tasks(user_id, start_at);
create index if not exists tasks_user_completed_idx on public.tasks(user_id, is_completed, completed_at desc);
create index if not exists tasks_series_idx on public.tasks(user_id, series_id, start_at);

create table if not exists public.settings (
  user_id uuid primary key references auth.users(id) on delete cascade,
  default_is_study boolean not null default true,
  default_section_id uuid,
  default_timer_hours integer not null default 0,
  default_timer_minutes integer not null default 25,
  auto_delete_period integer not null default 7,
  daily_notification_time text not null default '07:00',
  notification_enabled boolean not null default true,
  sort_option text not null default 'custom',
  theme text not null default 'mint',
  updated_at timestamptz not null default now()
);

create table if not exists public.timer_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  active_task_id uuid references public.tasks(id) on delete set null,
  is_running boolean not null default false,
  has_started boolean not null default false,
  mode text not null default 'timer',
  started_at timestamptz,
  accumulated_seconds double precision not null default 0,
  total_duration_seconds double precision not null default 1500,
  revision bigint not null default 0,
  updated_by_device_id text not null default '',
  updated_at timestamptz not null default now()
);

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists profiles_touch_updated_at on public.profiles;
create trigger profiles_touch_updated_at before update on public.profiles for each row execute function public.touch_updated_at();
drop trigger if exists sections_touch_updated_at on public.sections;
create trigger sections_touch_updated_at before update on public.sections for each row execute function public.touch_updated_at();
drop trigger if exists tasks_touch_updated_at on public.tasks;
create trigger tasks_touch_updated_at before update on public.tasks for each row execute function public.touch_updated_at();
drop trigger if exists settings_touch_updated_at on public.settings;
create trigger settings_touch_updated_at before update on public.settings for each row execute function public.touch_updated_at();
drop trigger if exists timer_touch_updated_at on public.timer_state;
create trigger timer_touch_updated_at before update on public.timer_state for each row execute function public.touch_updated_at();

alter table public.profiles enable row level security;
alter table public.sections enable row level security;
alter table public.tasks enable row level security;
alter table public.settings enable row level security;
alter table public.timer_state enable row level security;

drop policy if exists profiles_self on public.profiles;
create policy profiles_self on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists sections_self on public.sections;
create policy sections_self on public.sections for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists tasks_self on public.tasks;
create policy tasks_self on public.tasks for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists settings_self on public.settings;
create policy settings_self on public.settings for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists timer_self on public.timer_state;
create policy timer_self on public.timer_state for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Realtime: add the tables once in a fresh Supabase project.
alter publication supabase_realtime add table public.tasks;
alter publication supabase_realtime add table public.sections;
alter publication supabase_realtime add table public.settings;
alter publication supabase_realtime add table public.profiles;
alter publication supabase_realtime add table public.timer_state;


-- Avatar storage (public bucket for a single-user app; tighten policies before sharing with multiple users).
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true) on conflict (id) do update set public = true;

drop policy if exists avatars_insert on storage.objects;
create policy avatars_insert on storage.objects for insert to authenticated with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists avatars_update on storage.objects;
create policy avatars_update on storage.objects for update to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists avatars_delete on storage.objects;
create policy avatars_delete on storage.objects for delete to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
