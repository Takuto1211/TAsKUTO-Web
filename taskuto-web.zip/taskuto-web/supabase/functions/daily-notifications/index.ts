// Scaffold only: Web Push backend is intentionally separated from the client.
// Fill this in after VAPID keys and a push subscription table are configured.
import { serve } from 'https://deno.land/std@0.224.0/http/server.ts'
serve(async () => new Response(JSON.stringify({ ok: true, message: 'Notification worker scaffold ready.' }), { headers: { 'content-type': 'application/json' } }))
