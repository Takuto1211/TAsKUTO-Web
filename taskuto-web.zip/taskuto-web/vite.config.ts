import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['icons/apple-touch-icon.png', 'icons/pwa-192.png', 'icons/pwa-512.png'],
      manifest: {
        name: 'TAsKUTO',
        short_name: 'TAsKUTO',
        description: 'パーソナライズド・タスク管理アプリ',
        lang: 'ja',
        start_url: '/',
        display: 'standalone',
        orientation: 'any',
        theme_color: '#76d8b3',
        background_color: '#eefbf5',
        icons: [
          { src: '/icons/pwa-192.png', sizes: '192x192', type: 'image/png' },
          { src: '/icons/pwa-512.png', sizes: '512x512', type: 'image/png' },
          { src: '/icons/pwa-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }
        ]
      },
      workbox: {
        navigateFallbackDenylist: [/^\/supabase\//]
      },
      devOptions: { enabled: true }
    })
  ],
  server: { host: true }
})
